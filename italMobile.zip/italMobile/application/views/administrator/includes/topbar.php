<div class="topbar">
    <img src="<?php echo base_url(); ?>assets/images/logo.png">
</div>