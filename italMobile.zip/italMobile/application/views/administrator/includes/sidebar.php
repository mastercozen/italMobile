<div class="sidebar">
    <ul>
        <li><a href="<?php echo base_url() ?>Administrator_page"><span class="glyphicon glyphicon-dashboard"></span>&nbsp;&nbsp;Dashboard</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/manage_product"><span class="glyphicon glyphicon-th"></span>&nbsp;&nbsp;Manage Products</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/inventory_in_online"><span class="glyphicon glyphicon-th-list"></span>&nbsp;&nbsp;Inventory</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/manage_orders"><span class="glyphicon glyphicon-align-justify"></span>&nbsp;&nbsp;Manage Orders</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/reports"><span class="glyphicon glyphicon-equalizer"></span>&nbsp;&nbsp;Sales Report</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/customer_settings"><span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;Manage Customers</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/staff_settings"><span class="glyphicon glyphicon-tower"></span>&nbsp;&nbsp;Manage Staff</a></li>
        <!-- <li><a href="<?php echo base_url() ?>Administrator_page/view_feedbacks"><span class="glyphicon glyphicon-envelope"></span>&nbsp;&nbsp;Feedbacks</a></li> -->
     
        <li><a href="<?php echo base_url() ?>Administrator_page/cms"><span class="	glyphicon glyphicon-eye-open"></span>&nbsp;&nbsp;CMS</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/administrator_settings"><span class="	glyphicon glyphicon-wrench"></span>&nbsp;&nbsp;Administrator Settings</a></li>
        <li><a href="<?php echo base_url() ?>Administrator_page/logout"><span class="glyphicon glyphicon-off"></span>&nbsp;&nbsp;Logout</a></li>
    </ul>
</div>