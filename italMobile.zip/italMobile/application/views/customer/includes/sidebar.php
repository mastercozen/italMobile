        <div id="wrapper">
            
            <div id="sidebar-wrapper">
            	<style>
                    .test2{
                        width:250px;
                        background-color: #f00;
                        color:#fff;
                        padding: 10px;
                        position: relative;
                    }
                </style>
                <!--
                <div class="test2">
                    Not yet the official site of Italiannis™.<br>
                    This site is on Alpha Testing.
                </div>-->
                <div class="sidebar-brand">
                    <a href="#"><img src="<?php echo base_url() ?>assets/images/logo.png"></a>
                </div>
                <ul class="sidebar-nav">
                    <li><a href="<?php echo base_url() ?>home">Home</a></li>
               
                    <li><a href="<?php echo base_url() ?>shop">Shop</a></li>
                   <!--  <li><a href="<?php echo base_url() ?>feedback">Feedback</a></li> -->
                    
                    <br>
                    
                </ul>
            </div>

            <div id="page-content-wrapper">
                
                <div class="logo">
                    <img src="<?php echo base_url() ?>assets/images/logo.png">
                </div>