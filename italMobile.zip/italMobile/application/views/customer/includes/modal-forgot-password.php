<div class="modal fade modal" id="forgot-password" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Forgot password</h4>
            </div>
            <form method="post" action="#">
            <div class="modal-body">
                <div class="for1m-group">
                    <label>Enter your Email</label>
                    <input type="text"  name="street" class="form-control">
                </div>
            </div>            
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Add Address</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
            </form>
        </div>
    </div>
</div>