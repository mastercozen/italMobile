
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#" id="menu-toggle">
                        <span class="glyphicon glyphicon-menu-hamburger"/></span>
                    </a>
                    <!-- <a href="<?php echo base_url()?>" class="navbar-brand" href="#" style="font-size:14px;">
                        Italiannis : Pasta, Pizza and Wings
                    </a> -->
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="border:0px;">
                        <span class="glyphicon glyphicon-menu-down"></span>                    
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <!-- <li><a href="<?php echo base_url() ?>register">Login <span class="glyphicon glyphicon-chevron-right"></span></a></li>  -->
                    </ul>
                </div>
            </div>
        </nav>

        <script type = "text/javascript" src = "<?php echo base_url() ?>assets/js/custom.js"></script>