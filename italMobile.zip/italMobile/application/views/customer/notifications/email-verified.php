<div class="container-fluid">
    <br>
    <br>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="panel panel-warning">
               <div class="panel-heading">
                   <h3 class="panel-title">From Italiannis</h3>
               </div>
                
               <div class="panel-body">
                   Your account is now activated. <br><br>
                   <a href="<?php echo base_url() ?>register">Back to Home</a>
               </div>
                
            </div>
       </div>
    </div>
    
    <BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
</div>