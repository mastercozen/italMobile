<div class="topbar">
    <img src="<?php echo base_url(); ?>assets/images/white.png">
</div>