<div class="sidebar">
    <ul>
        <li><a href="<?php echo base_url() ?>Staff_page"><span class="glyphicon glyphicon-dashboard"></span>&nbsp;&nbsp;Dashboard</a></li>
        <li><a href="<?php echo base_url() ?>Staff_page/manage_product"><span class="glyphicon glyphicon-th"></span>&nbsp;&nbsp;Manage Products</a></li>
        <li><a href="<?php echo base_url() ?>Staff_page/inventory_in_online"><span class="glyphicon glyphicon-th-list"></span>&nbsp;&nbsp;Inventory</a></li>
        <li><a href="<?php echo base_url() ?>Staff_page/manage_orders"><span class="glyphicon glyphicon-align-justify"></span>&nbsp;&nbsp;Manage Orders</a></li>
        <li><a href="<?php echo base_url() ?>Staff_page/reports"><span class="glyphicon glyphicon-equalizer"></span>&nbsp;&nbsp;Sales Report</a></li>
        <li><a href="<?php echo base_url() ?>Staff_page/customer_settings"><span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;Manage Customers</a></li>
        <li><a href="<?php echo base_url() ?>Staff_page/view_feedbacks"><span class="glyphicon glyphicon-envelope"></span>&nbsp;&nbsp;Feedbacks</a></li>
        <li><a href="<?php echo base_url() ?>Staff_page/logout"><span class="glyphicon glyphicon-off"></span>&nbsp;&nbsp;Logout</a></li>
    </ul>
</div>